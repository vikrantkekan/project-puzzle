<!-- Entry -->
  <div class="modal fade" id="entry" role="dialog" data-backdrop='static'>
    <div class="modal-dialog modal-md" style="background-color:#23211f;color:#fff;">
      <!-- Modal content-->
      <div class="modal-content" style="background-color:#23211f;border: 1px solid #fecc00;border-radius: 15px;">
        <div class="modal-body">
        		
        		<div class="row" style="padding:21px;">
        		<div class="col-md-12">
        		<p style="font-size:45px;letter-spacing: 1.5px;">Welcome! To continue in the game, please enter your name</p>
        		<br>
        		<input type="text" name="myname" id="myname" placeholder="Enter Your Name" style="background-color:transparent;height:45px;width:100%;border:1px solid #fecc00;font-size: 18px;" required>

        		<p id="loginmsg"></p>
				</div>	
				</div>
				<div class="row" style="padding:21px;">
					<div class="col-md-12">
        		<button type="button" onClick="enterplay();" class="btn" style="background-color:transparent;border: 1px solid #fecc00;color:#fff;font-size:21px;">Play Now </button> 
        			</div>
        		<br>
        		</div>
					
        </div>
      </div>
    </div>
  </div>