<center>

 <div style="color:#000;">
      <!-- Modal content-->
      <div class="modal-content" style="background-color:#fecc00;border: 1px solid #000;border-radius: 15px;position: relative;">
        <div class="modal-body">
        	<div class="row" style="padding:21px;position: relative;">
        		<div class="col-md-12" style="position: relative;">
        		<p style="font-size:45px;letter-spacing: 1.5px;z-index: 99;"> Client put project on hold <br>
<img class="shaket" src="modals/svg/10.svg" style="position: absolute;top: 100px;right:0;width: 150px;z-index: 0;">
        		</p>
						</div>
						
					</div>
					<div class="row" style="padding:21px;">
        		<button data-dismiss="modal" type="button" class="btn" style="background-color:transparent;border: 1px solid #23211f;color:#23211f;font-size:21px;">Wait 2 turns </button> 
        		<br>
        		</div>
        </div>
      </div>
    </div>

</center>