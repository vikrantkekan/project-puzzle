<!-- Modal number 5 -->
  <div class="modal fade" id="thirteen" role="dialog" >
    <div class="modal-dialog modal-md" style="background-color:#23211f;color:#fff;">
      <!-- Modal content-->
      <div class="modal-content" style="background-color:#23211f;border: 1px solid #fecc00;border-radius: 15px;">
        <div class="modal-body">
        	<div class="row" style="padding:21px;">
        		<div class="col-md-7">
        		<p style="font-size:45px;letter-spacing: 1.5px;">Won a new client pitch<br>
        		</p>
						</div>
						<div class="col-md-5">
        		<img class="shake" src="modals/svg/13.svg" style="width:80%;">
						</div>
					</div>
					<div class="row" style="padding:21px;">
        		<button data-dismiss="modal" type="button" class="btn" style="background-color:transparent;border: 1px solid #fecc00;color:#fff;font-size:21px;">Go up to 28 </button> <img class="mymovel" src="icons/5/3.svg" style="width:5%;">
        		<br>
        		</div>
        </div>
      </div>
    </div>
  </div>