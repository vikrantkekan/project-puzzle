<!-- Modal number 5 -->
  <div class="modal fade" id="invite" role="dialog" style="margin-top:5%;">
    <div class="modal-dialog modal-md" style="background-color:#23211f;color:#fff;">
      <!-- Modal content-->
      <div class="modal-content" style="background-color:#23211f;border: 1px solid #fecc00;border-radius: 15px;">
        <div class="modal-body">
          <div class="row" style="padding:21px;">
            <div class="col-md-7">
            <p style="font-size:45px;letter-spacing: 1.5px;">Invite your freind on<br>
            </p>
            </div>
            <div class="col-md-5">
            <img class="shake" src="modals/svg/13.svg" style="width:80%;">
            </div>
          </div>

          <div class="row" style="padding:21px;">
              <div class="share-buttons" style="display: flex;justify-content: space-evenly;">

        <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=https://3dotsdesign.in/game/" target="_blank" style="padding:15px;border:1px solid #fff;color:#fff;">
            Facebook
        </a>

        <a class="whatsapp" href="https://api.whatsapp.com/send?text=Check%20out%20this%20amazing%20game!%20https://3dotsdesign.in/game/" target="_blank" style="padding:15px;border:1px solid #fff;color:#fff;">
            WhatsApp
        </a>
        <a class="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=https://3dotsdesign.in/game/&title=Amazing%20Game&summary=Check%20this%20out!" target="_blank" style="padding:15px;border:1px solid #fff;color:#fff;">
            LinkedIn
        </a>
    </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>