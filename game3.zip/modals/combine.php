<!-- Modal number 5 -->
  <div class="modal fade" id="combine" role="dialog" >
    <div class="modal-dialog modal-md" style="background-color:#23211f;color:#fff;">
      <!-- Modal content-->
      <div class="modal-content" style="background-color:#23211f;border: 1px solid #fecc00;border-radius: 15px;">
        <div class="modal-body">
        	<div class="row" style="padding:21px;">
        		<div class="col-md-12">
        		<img src="tiles/10.png" style="width:100%;" />
						</div>
						
					</div>

					<div class="row" style="padding:21px;">
        		<button data-dismiss="modal" type="button" class="btn" style="background-color:transparent;border: 1px solid #fecc00;color:#fff;font-size:21px;">OK </button> <img class="mymovel" src="icons/5/3.svg" style="width:5%;">
        		<br>
        		</div>
        </div>
      </div>
    </div>
  </div>