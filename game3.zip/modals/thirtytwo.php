<!-- Modal number 5 -->
  <div class="modal fade" id="thirtytwo" role="dialog" >
    <div class="modal-dialog modal-md" style="color:#000;">
      <!-- Modal content-->
      <div class="modal-content" style="background-color:#fecc00;border: 1px solid #000;border-radius: 15px;height:380px;">
        <div class="modal-body">
        	<div class="row" style="padding:21px;">
        		<div class="col-md-12">
        		<p style="font-size:45px;letter-spacing: 1.5px;">Content goes viral on social media!<br>
              <img class="shake" src="modals/svg/png/32.png" style="position: absolute;top: 130px;right:0;width: 150px;z-index: 0;">
					</p>
				</div>
						
				</div>
					<div class="row" style="padding:21px;">
        		<button data-dismiss="modal" type="button" class="btn" style="background-color:transparent;border: 1px solid #23211f;color:#23211f;font-size:21px;">Go up to 40</button> <img class="mymovel" src="icons/5/3.svg" style="width:7%;">
        		<br>
        		</div>
        </div>
      </div>
    </div>
  </div>