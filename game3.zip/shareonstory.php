<a 
  href="instagram://story-camera?background_image=https://example.com/image.jpg" 
  target="_blank">
  Share to Instagram Stories
</a>